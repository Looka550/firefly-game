export class Light {

    constructor({
        resolution = [512, 512],
    } = {}) {
        this.resolution = resolution;
    }

}
