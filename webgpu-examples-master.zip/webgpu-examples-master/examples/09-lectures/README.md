Imenik vsebuje primere, ki jih kažemo na predavanjih, ko obravnavamo posamezna poglavja. 
Koda je namenjena ilustraciji posameznih konceptov in ni nujno lep primer programiranja v WebGPU.